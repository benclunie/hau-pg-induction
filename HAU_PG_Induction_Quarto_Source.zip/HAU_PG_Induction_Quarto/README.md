# Applied ecology postgraduate induction

Editable Quarto/RevealJS project based on `HAU PG Induction.pptx`.

## Files

- `HAU_PG_Induction.qmd`: all slides and speaker notes.
- `joe-quarto.css`: the governing stylesheet, including local Montserrat fonts.
- `_quarto.yml`: project configuration; rendered files go in `_site`.
- `assets/`: original source images and the skill's supplied Harper Adams branding and fonts.

## Preview and render

Install Quarto if it is not already available on your own computer. In Positron, open this project folder and the QMD, then select **Preview**. Alternatively, in a terminal in this folder:

```sh
quarto preview HAU_PG_Induction.qmd
quarto render HAU_PG_Induction.qmd
```

The rendered presentation will be `_site/HAU_PG_Induction.html`. The configuration embeds local assets in that single HTML file. It can be opened in a modern browser without the project folder. Keep the entire source project together when editing or rebuilding.

## Presenting and interaction

- Use the arrow keys or on-screen arrows to move through slides. `Esc` opens the overview; `S` opens the speaker view.
- The course names and research-section links jump to named slides.
- Each research group has a prominent **Open the live research group page** link. It opens the official page in a new tab. Browse and follow project or staff links there; close the tab or return to the presentation tab to resume at the same slide.
- Both group links also appear on the final Questions slide.
- Two student-support slides follow Assessment and support: an overview of services and direct links that open in new tabs.
- Research-group overviews and discussion questions are permanently visible for live teaching. No dropdowns are needed.
- A single organogram shows the two groups and staff, including the presenter’s addition of Jack Bamber and group leads above their teams and Joe Roberts first in the Applied Entomology staff list. Click a group heading to open its page.
- Presentation content and local images work offline after rendering. Live group websites require internet access. Check the pages on the classroom computer before teaching.
- Browser fullscreen may close when changing tabs. Re-enter fullscreen after returning if needed.

## Editing

Each level-two heading starts a slide. Its `#identifier` is used by internal jump links; preserve it or update the links when changing it. Editable text sits directly in the QMD, including the HTML layout blocks. Speaker notes are inside `.notes` blocks. Image paths are relative to this folder. Slide layouts and typography are in the one CSS file.

## Source content decisions

The induction narrative is retained. Staff membership in the new organogram follows the two public research-group pages. Staff headshots have been removed, and the accent colour is a lighter blue. The empty source slide is removed. Facilities and research sections have been separated to make them readable. The original 23 collaboration logos are split across two slides, with Forest Research added to the industry slide. The research-group overviews replace specific project examples. Detailed project choices will be covered separately later in the term.

Clear source errors corrected:

- British spelling `ageing`, `Systematics` in Insect Systematics and Diversity, and plural Human Insect Interactions.
- Biological Recording award names replace copied IPM labels.
- Biological Recording PgD requires 30 **further** optional credits after PgC, giving 65 optional credits across both awards. Official module credits confirm the arithmetic.
- The stray `576` is removed.
- Typical taught module study hours are distinguished from the 60-credit Masters Research Project.

Items to confirm before teaching:

- The source course groupings and IPM option list are retained. The public IPM course page currently lists Regenerative Approaches for Contemporary Farming Systems and Forest and Woodland Management; it does not list the source's Human Insect Interactions option. Confirm the approved choices for this cohort.
- Biological Recording's official module record says **Experimental Design and Qualitative Analysis**. This is retained, although the timetable uses Experimental Design and Analysis.
- Submission deadlines, late penalties, rooms and programme-support staff names and roles follow your source rather than being treated as a newly validated policy or directory.
- Source reference labels on the skills-gap slide are retained as broad references; the committee-report year was not reasserted on the slide.
- Source farm area and culture counts remain in speaker notes because they may change.

## Sources checked

Research pages, 17 September 2026:

- https://www.harper-adams.ac.uk/research/966/research-centre/entomology-group/
- https://www.harper-adams.ac.uk/research/1307/research-centre/ecology-evolution-and-conservation-group/

Biological Recording award and credit checks:

- https://www.harper-adams.ac.uk/documents/postgraduate/260910-Timetable-2026-27930727.pdf
- https://www.harper-adams.ac.uk/shared/get-module.cfm?id=202316
- https://www.harper-adams.ac.uk/shared/get-module.cfm?id=202318
- https://www.harper-adams.ac.uk/shared/get-module.cfm?id=202331
- https://www.harper-adams.ac.uk/shared/get-module.cfm?id=201738

Full source details and image provenance are also included in speaker notes.

## Build status

The 22-slide deck was rendered using Quarto 1.10.18. The package includes the complete editable project and the self-contained `_site/HAU_PG_Induction.html`. Open the HTML in a modern browser to present, or edit the QMD in Positron and render again.

Research-group staff and visiting-researcher membership was checked against the official group pages on 17 September 2026. Jack Bamber is included at the presenter’s request and his name is verified on his official profile. Group leads Tom Pope and Simon Segar appear above their teams. Joe Roberts appears first in the Applied Entomology staff list in regular type. The organogram shows group affiliation. Separately listed PhD students are omitted from this staff overview.

Forest Research logo: https://cdn.forestresearch.gov.uk/2024/10/Forestry-logo-2024.svg, displayed on the official https://www.forestresearch.gov.uk/ homepage. Jack Bamber profile: https://www.harper-adams.ac.uk/general/staff/profile/207037/Jack-Bamber/.

Student-support content and service links were checked using the official directory and its linked pages on 17 September 2026: https://www.harper-adams.ac.uk/study/820/university-life/student-support/ . The student-support overview also uses the official academic-support and disability-support pages.
