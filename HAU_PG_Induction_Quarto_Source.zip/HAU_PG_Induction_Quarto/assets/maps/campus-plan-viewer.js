(() => {
  function initialiseCampusPlan() {
    const opener = document.getElementById('open-campus-plan');
    const source = document.getElementById('campus-plan-image');
    if (!opener || !source) return;
    const dialog = document.createElement('dialog');
    dialog.id = 'campus-plan-dialog';
    dialog.setAttribute('aria-labelledby', 'campus-plan-dialog-title');
    dialog.innerHTML = `<div class="campus-viewer-toolbar">
      <h2 id="campus-plan-dialog-title">Harper Adams campus plan</h2>
      <div class="campus-viewer-controls">
        <button type="button" data-map-action="out" aria-label="Zoom out">−</button>
        <output aria-live="polite">100%</output>
        <button type="button" data-map-action="in" aria-label="Zoom in">+</button>
        <button type="button" data-map-action="fit">Fit</button>
        <button type="button" data-map-action="close">Close</button>
      </div>
    </div><div class="campus-viewer-viewport" tabindex="0" aria-label="Campus plan: drag or scroll to explore">
      <img alt="Full Harper Adams campus plan with numbered building and facility keys" draggable="false">
    </div><p class="campus-viewer-help">Zoom in for building labels · Drag or scroll to explore · Escape to return</p>`;
    document.body.append(dialog);
    const viewport = dialog.querySelector('.campus-viewer-viewport');
    const map = viewport.querySelector('img');
    const output = dialog.querySelector('output');
    const zoomOut = dialog.querySelector('[data-map-action="out"]');
    const zoomIn = dialog.querySelector('[data-map-action="in"]');
    let scale = 1, fitWidth = 0, previousKeyboard = true, drag = null;
    function resizeMap(nextScale, reset = false) {
      const previousWidth = map.clientWidth || fitWidth;
      const previousMargin = Math.max(0, (viewport.clientWidth - previousWidth) / 2);
      const centreX = (viewport.scrollLeft + viewport.clientWidth / 2 - previousMargin) / previousWidth;
      const centreY = (viewport.scrollTop + viewport.clientHeight / 2) / previousWidth;
      scale = Math.max(1, Math.min(6, nextScale));
      map.style.width = `${fitWidth * scale}px`;
      output.value = `${Math.round(scale * 100)}%`;
      zoomOut.disabled = scale <= 1;
      zoomIn.disabled = scale >= 6;
      viewport.scrollLeft = reset ? 0 : centreX * fitWidth * scale - viewport.clientWidth / 2;
      viewport.scrollTop = reset ? 0 : centreY * fitWidth * scale - viewport.clientHeight / 2;
    }
    function fit() {
      const ratio = (source.naturalWidth || 1224.57) / (source.naturalHeight || 875.905);
      fitWidth = Math.min(viewport.clientWidth, viewport.clientHeight * ratio);
      resizeMap(1, true);
    }
    opener.addEventListener('click', () => {
      map.src = source.currentSrc || source.src;
      previousKeyboard = window.Reveal ? Reveal.getConfig().keyboard : true;
      if (window.Reveal) Reveal.configure({ keyboard: false });
      dialog.showModal();
      fit();
      viewport.focus();
    });
    dialog.addEventListener('click', event => {
      const action = event.target.closest('[data-map-action]')?.dataset.mapAction;
      if (action === 'in') resizeMap(scale * 1.5);
      if (action === 'out') resizeMap(scale / 1.5);
      if (action === 'fit') fit();
      if (action === 'close') dialog.close();
    });
    dialog.addEventListener('close', () => {
      drag = null;
      if (window.Reveal) Reveal.configure({ keyboard: previousKeyboard });
      opener.focus();
    });
    viewport.addEventListener('pointerdown', event => {
      if (event.pointerType === 'touch' || event.button !== 0) return;
      drag = { x: event.clientX, y: event.clientY, left: viewport.scrollLeft, top: viewport.scrollTop };
      viewport.setPointerCapture(event.pointerId);
      viewport.classList.add('is-dragging');
      event.preventDefault();
    });
    viewport.addEventListener('pointermove', event => {
      if (!drag) return;
      viewport.scrollLeft = drag.left - (event.clientX - drag.x);
      viewport.scrollTop = drag.top - (event.clientY - drag.y);
    });
    for (const eventName of ['pointerup', 'pointercancel', 'lostpointercapture']) {
      viewport.addEventListener(eventName, () => {
        drag = null;
        viewport.classList.remove('is-dragging');
      });
    }
    window.addEventListener('resize', () => { if (dialog.open) fit(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialiseCampusPlan);
  else initialiseCampusPlan();
})();
