# GitHub Pages

The live presentation is https://benclunie.github.io/hau-pg-induction/ and its repository is https://github.com/benclunie/hau-pg-induction . GitHub Pages hosts the static presentation. It has no server-side code or database.

## Repository files

- `index.html`: the self-contained rendered presentation.
- `.nojekyll`: tells GitHub Pages to serve files directly.
- `HAU_PG_Induction_Quarto_Source.zip`: the complete editable Quarto project, including QMD, CSS, fonts, assets and rendered HTML.

## Update the presentation

Extract the source ZIP, edit the QMD, render with Quarto, then copy the new HTML to the repository root as `index.html` and commit the change. Replace the source ZIP when the editable project changes.

```sh
unzip HAU_PG_Induction_Quarto_Source.zip
cd HAU_PG_Induction_Quarto
quarto render HAU_PG_Induction.qmd
cp _site/HAU_PG_Induction.html ../index.html
```

To publish, use Settings → Pages → Deploy from a branch, choosing `main` and the root folder. Use the resulting Pages URL on the classroom computer. Website links inside the presentation open in new tabs.
